"""
Create class Warrior
Warrior class attribute:  strength, agility
Warrior instance attributes: health, mana
Warrior instance methods: heal()
heal() adds 1 health to instance that called it
Create 2 instances of Warrior
Print strength for first instance
Call heal() for second instance
Print health for both instances
"""


class Warrior:
    ...
