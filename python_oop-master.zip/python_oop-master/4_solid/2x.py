"""
Make Exporter class with export() method
Exporter should be closed for modification but open for extension
Extend it so that you can export pdf, xlsx and png files
"""


class Exporter:
    ...
